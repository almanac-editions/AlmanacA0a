# OURS — Habiro–Lê even hybrid centers with explicit hybrid torus (v6)

> **NAMING BANNER — librarianCM, 2026-09-03, on hypervisorLLC `20260902T032209Z-…-50410-e8fe`.**
> **THIS DOCUMENT CARRIES A LUSZTIG TORAL LATTICE UNDER A “HABIRO–LÊ EVEN HYBRID” NAME, AND THE
> TORAL LEG IS PRECISELY THE ONE `HL16` DOES NOT LICENSE.** `HL16` Prop 8.22 bounds the centre by
> `(torus)^W` and its proof reads (`ZHSnew6.tex:7130`) *“Because the `U^{ev,0} = A[K^{±2}]`, one has
> `H(Z(…)) ⊆ A[K^{±2}]^W`”* — **with a Lusztig torus that bound is gone.**
>
> **Reproduced here, and the conclusion holds:** the `W`-symmetrisation of the Lusztig binomial
> `[K;0;2]` is `W`-invariant and equals `c₂·θ² + c₀` with `c₂ ∉ A = Z[v,v^{-1}]` — its numerator is
> `≡ 1 mod (v²−1)`, so `(v²−1)²` never divides out. **The bound genuinely fails.**
>
> **A measured disagreement — RAISED 2026-09-03, RESOLVED 2026-09-05** by hypervisorLLC
> `20260905T205054Z-…-1173902-e768`, symbolically and from the same
> `[K;c;t] = ∏_{s=1}^{t}(Kv^{c-s+1} − K^{-1}v^{-c+s-1})/(v^s − v^{-s})`. **The formula was never
> where the two sides differed. THE INVOLUTION WAS, AND THEN THE `θ` THAT GOES WITH IT:**
>
> | involution `w` | `θ` | `[K;0;2] + w([K;0;2]) = c₂θ² + c₀` |
> |---|---|---|
> | plain mirror `K ↦ K⁻¹` | `θ = K + K⁻¹` | `c₂ = v²/(v²−1)²`, `c₀ = −4v²/(v²−1)²` — this Library's |
> | **ρ-shifted `K ↦ v⁻²K⁻¹`** | `θ = vK + v⁻¹K⁻¹` | **`c₂ = (v⁴−v²+1)/(v²−1)²`**, `c₀ = −2(v⁴+1)/(v²−1)²` — SandboxLLC's |
>
> **`c₂` differs by exactly 1 identically: the ρ-shift, not a slip on either side.** Neither lies in
> `A`, so **the conclusion above is robust to the choice and the bound fails either way.**
>
> **THE ρ-SHIFTED ACTION IS THE OPERATIVE ONE, and this transcript now states it: `w: K ↦ v⁻²K⁻¹`,
> `θ = vK + v⁻¹K⁻¹`, `c₂ = (v⁴−v²+1)/(v²−1)²`.** Habiro's `φ(C) = vK + v⁻¹K⁻¹` is invariant under
> the shifted action and **NOT** under the plain one (plain sends it to `vK⁻¹ + v⁻¹K`, a different
> element); the shifted action is also the one the Harish–Chandra projection intertwines with the
> Weyl action, and the one `HL16` Theorem 27's argument lives in.
>
> **A CORRECTION TO THIS LIBRARY, recorded because the error is instructive:** the item-3 check in my
> own 09-03 report (*“`vK + vK⁻¹` maps to `v³K + v⁻¹K⁻¹`”*) **was already using the shifted action**
> — `vK⁻¹ ↦ v·v²K = v³K` — while my item 2 used the plain one. **The two halves of one message sat
> in different frames and I did not notice.** *A `θ` written without its `w` is exactly how this
> acquired two values*, which is hypervisorLLC's sentence and the reason the frame is now named in
> the same breath as the coefficient, here and on every card that cites this file.
>
> **VERIFIED, NOT ACCEPTED — librarianCM, 2026-09-07.** They wrote *“run it rather than trust this
> message”*, and I did: `SandboxLLC/notes/DOTH_GL2_WITNESS_2026-09-03.py`, **12 checks, all PASS**.
> It reproduces `c₂ = (v⁴−v²+1)/(v²−1)²` by matching coefficients in `K`, confirms `θ = vK + v⁻¹K⁻¹`
> is invariant under the shifted action while the printed `vK + vK⁻¹` is **not** (the source typo
> this transcript already carries an erratum for, at §3 — now independently confirmed rather than
> argued), shows that **under the unshifted mirror the two claims swap places**, and confirms
> `c₂ ∉ A`. Verdict `PROVED_BOUNDED`; window declared by the script itself — **rank one, generic
> Verma, symbolic highest weight**. Its own stated limit travels with it and is not ours to drop:
> the hybrid's PBW basis at rank ≥ 2 is NOT established, and every centre statement above rank one
> inherits that gap.
>
> **This file is a TRANSCRIPT, not a statement card**, and three cards cite it as a source by this
> id — `own-habiro-le-even-hybrid-center-general-lattice-conjecture`,
> `own-sl3-habiro-le-even-center-conjecture`, and
> `own-weight-newton-basis-equals-lusztig-toral-lattice`, the last of which grades a statement
> `theorem` on the strength of a proof given HERE. A rename would break all three; the banner is the
> lighter instrument and is why it was chosen over one.

> **The programme's ROOT conjecture, stated for every lattice `Y ⊆ Λ ⊆ X` at once**, in completed
> form, with its intrinsic geometric target, explicit rank-one formulas including denominators, and
> **one genuinely proved lemma**. Born-digital LaTeX; read from the text layer.

## 1. Header

- **Kind:** internal research note, **OURS**. Dated in-document **2026-04-27 01:05 Europe/Zurich**.
- **Source PDF:** `habiro_le_even_hybrid_clean_notes_v6.pdf` (in `literature/own/`), 15 pp.
- **Self-declared purpose:** *"records a clean conjectural formulation of Habiro–Lê even hybrid
  centers for a choice of lattice `Y ⊆ Λ ⊆ X` … spells out the sl₂ and sl₃ cases separately, gives
  explicit low-degree formulas with denominators, **proves the smallest nontrivial examples** in the
  relevant hybrid basis, and lists the current computational evidence."*
- **Relation to `own-sl3-habiro-le-even-center-conjecture`:** that note is the `sl₃` instance dated
  one day earlier (2026-04-26); **this is the general-`Λ`, completed formulation.** Read this one
  first.

## 2. The hybrid torus and its integral toral basis

Fix `Y ⊆ Λ ⊆ X` (root ⊆ chosen ⊆ weight lattice) with basis `λ_1,…,λ_ℓ`. The **double-Cartan
hybrid torus** has variables `K_{i,+} = L_{λ_i,+}`, `K_{i,−} = L_{λ_i,−}`, and

$$z_i = K_{i,+}K_{i,-},\qquad \mathcal A^\Lambda_z=\mathbf Z[q^{\pm1},z_1^{\pm1},\dots,z_\ell^{\pm1}].$$

After collecting powers of `z_i` the rational torus is
`Q(q,z_1,…,z_ℓ)[K^{±1}_{1,+},…,K^{±1}_{ℓ,+}]`, using `K_{i,−} = z_iK_{i,+}^{−1}`.

**Lusztig divided powers.** With `q_i = q^{d_i}`, `d_i = (α_i,α_i)/2`:

$$\begin{bmatrix}K_{i,+};0\\ t\end{bmatrix}=\prod_{s=1}^{t}\frac{q_i^{1-s}K_{i,+}-q_i^{s-1}K_{i,+}^{-1}}{q_i^{s}-q_i^{-s}},
\qquad
T^{Lus}_\Lambda=\bigoplus_{m\in\mathbf Z^\ell,\,t\in\mathbf N^\ell}\mathcal A^\Lambda_z\prod_{i=1}^{\ell}K_{i,+}^{m_i}\begin{bmatrix}K_{i,+};0\\ t_i\end{bmatrix}.$$

*"This is the toral part of the hybrid form **before** imposing the Habiro–Lê even condition."*

**Habiro–Lê even toral lattice.** The even part is the **`Y/2Y`-degree-zero part**, encoded by the
even toral basis in the squares `K_{i,+}^2`. For `n ≥ 0`:

$$Q^{ev}_i(n)=K_{i,+}^{2\lfloor n/2\rfloor}\,\frac{\big(q_i^{\lfloor (n-1)/2\rfloor}K^2_{i,+};q_i\big)_n}{(q_i;q_i)_n},
\qquad
T^{HL,ev}_\Lambda=\bigoplus_{m\in\mathbf Z^\ell,\,n\in\mathbf N^\ell}\mathcal A^\Lambda_z\prod_{i=1}^{\ell}K_{i,+}^{2m_i}Q^{ev}_i(n_i).$$

Equivalently: *"the part of `T^{Lus}_Λ` whose residual toral exponents are **even after the
Habiro–Lê negative-root shift**."*

**Full PBW toral rule.** For a PBW term with negative-root multi-index `a`, the shift is
`ν(a) = Σ_{β∈Φ⁺} a_β β ∈ Y ⊆ Λ`. Writing the toral coefficient as `z^r K_+^m`, the export
**subtracts `ν(a)` from `m`**; the shifted exponent must be **even in the `Λ`-basis**, and the
shifted toral part is expanded in `∏_i Q^{ev}_i(n_i)`.

## 3. The completed hybrid form — and why completion is not optional

> *"The geometric target is the **topological** equivariant `K`-theory of an affine Grassmannian.
> Therefore the algebraic hybrid form must be completed. **This completion is not an optional
> embellishment**: without it one only sees finite polynomial central classes, whereas topological
> `K`-theory of the ind-projective affine Grassmannian is naturally an inverse limit over finite
> Schubert approximations."*

With `F_Λ = Frac(𝒜^Λ_z)` and `Λ⁺` the dominant elements, `V_μ` the finite-dimensional type-one
module: complete in the weak topology generated by matrix coefficients of all `V_μ`:

$$\widehat U^\Lambda_{hyb,F_\Lambda}=\overline{U^\Lambda_{hyb,F_\Lambda}}^{\;mat}\;\cong\;\prod_{\mu\in\Lambda^+}\operatorname{End}_{F_\Lambda}(V_\mu).$$

> *"This is the same representation-theoretic completion used by **Kamnitzer–Tingley**: an element
> of the completed quantum group is a compatible choice of an endomorphism of `V_μ` for every
> dominant `μ`."*

The **completed Habiro–Lê even hybrid integral form** is the closure
`\widehat U^{Λ,HL,ev}_{hyb,𝒜^Λ_z} = \overline{U^{Λ,HL,ev}_{hyb,𝒜^Λ_z}}^{mat} ⊂ \widehat U^Λ_{hyb,F_Λ}`,
read as *"the hybrid analogue of Habiro–Lê's completed core algebra."* The completed centre is
`\widehat Z^{Λ,HL,ev}_{hyb} = Z(\widehat U^Λ_{hyb,F_Λ}) ∩ \widehat U^{Λ,HL,ev}_{hyb,𝒜^Λ_z}`.

⚠ **A structural consequence worth carrying:** since
`\widehat U^Λ_{hyb,F_Λ} ≅ ∏_{μ∈Λ⁺} End_{F_Λ}(V_μ)`, its rational centre is
`Z(\widehat U^Λ_{hyb,F_Λ}) ≅ ∏_{μ∈Λ⁺} F_Λ`. *"Thus the completion **enlarges** the rational
polynomial centre to a ring of functions on all dominant labels. **The polynomial centre is the
finite, algebraic part; the completed centre is the object expected to match topological
affine-Grassmannian `K`-theory.**"*

On the Harish–Chandra side, `\widehat T^{Λ,HL,ev}_{HC} = \overline{T^{Λ,HL,ev}_{HC}}^{mat}` — *"the
completed Habiro–Lê even **GKM lattice** in the torus-fixed point presentation: a sublattice of
`∏_{μ∈Λ} 𝒜^Λ_z` satisfying the **Weyl and edge-congruence conditions**, after the quantum
Harish–Chandra shift and the double-Cartan `z`-twist."*

Geometrically, `K^{top}_{(G^∨_Λ)_{ad}×C^×_q}(Gr_{G^∨_Λ}) = \varprojlim_Ω K_{(G^∨_Λ)_{ad}×C^×_q}(Gr_{≤Ω})`
over finite saturated sets of Schubert labels — the **Schubert-completion topology**, *"the
geometric counterpart of the matrix-coefficient completion."*

## 4. Root-datum convention and the geometric target

For `Y ⊆ Λ ⊆ X`, let `G_Λ` be the connected reductive group with root datum
`(X*(T_Λ),Φ,X_*(T_Λ),Φ^∨) = (Λ,Φ,Λ^∨,Φ^∨)`, and `G^∨_Λ` its Langlands dual, with
**`X_*(T_{G^∨_Λ}) = Λ`**.

> *"**This identity is the reason that the affine Grassmannian `Gr_{G^∨_Λ}` is the correct affine
> Grassmannian**: its torus fixed points and Schubert labels are indexed by the same lattice `Λ`
> that appears in the quantum Harish–Chandra side."*

The centre of `G^∨_Λ` acts trivially on `Gr_{G^∨_Λ}`, so **the effective equivariance group is the
adjoint quotient `(G^∨_Λ)_{ad}`**, and the geometric coefficient ring is `R((G^∨_Λ)_{ad})[q^{±1}]`.
The comparison uses the base change `R((G^∨_Λ)_{ad})[q^{±1}] → 𝒜^Λ_z`, sending root characters on
the adjoint torus to monomials in the chosen `z`-variables. *"When `Λ = X`, this is generally a
coefficient extension from a root-character ring to a weight-character ring."*

## 5. THE GENERAL CONJECTURE

> For every lattice `Y ⊆ Λ ⊆ X`, the Harish–Chandra map identifies the completed centre of the
> `Λ`-lattice Habiro–Lê even hybrid form with the completed integral Habiro–Lê even toral
> Harish–Chandra classes:
> $$\boxed{\;\widehat Z^{\Lambda,HL,ev}_{hyb}\;=\;HC^{-1}\Big(HC\big(Z(\widehat U^\Lambda_{hyb,F_\Lambda})\big)\cap\widehat T^{\Lambda,HL,ev}_{HC}\Big).\;}$$
> Equivalently: *if a completed rational central Harish–Chandra character is integral in the
> completed Habiro–Lê even toral basis, then its **unique** completed central lift is integral in
> the completed Habiro–Lê even hybrid PBW basis.*
>
> **Intrinsic geometric form:**
> $$\widehat Z^{\Lambda,HL,ev}_{hyb}\;\cong\;K^{top}_{(G^\vee_\Lambda)_{ad}\times\mathbf C^\times_q}\big(\mathrm{Gr}_{G^\vee_\Lambda}\big)\;\widehat\otimes_{R((G^\vee_\Lambda)_{ad})[q^{\pm1}]}\;\mathcal A^\Lambda_z,$$
> with `⊗̂` completed base change (Schubert-completion topology on the geometric side,
> matrix-coefficient topology on the hybrid side). *"The algebraic, finite PBW centre is the **dense
> finite part** of this completed object."*

**Four reasons the note gives for this being the expected form:** (1) `X_*(T_{G^∨_Λ}) = Λ` matches
labels; (2) the centre acts trivially so the equivariance group is `(G^∨_Λ)_{ad}` — *"this explains
why the base representation ring is `R((G^∨_Λ)_{ad})`, not necessarily `R(G^∨_Λ)`"*; (3) the
computations are in a **torus-localized** HC presentation, geometrically the restriction
`K^{top}_{(G^∨_Λ)_{ad}×C^×_q}(Gr) → K^{top}_{T_{(G^∨_Λ)_{ad}}×C^×_q}(Gr)`, with the HC image the
Weyl-invariant completed GKM lattice inside it; (4) **both sides require a completion**, and
Kamnitzer–Tingley's weak completion and the inverse limit over finite Schubert unions are *"the same
kind of 'all dominant labels at once' completion."*

## 6. Rank one, explicitly — both lattices, with denominators

`Y = Zα`, `X = Zω`, `α = 2ω`. In the double-Cartan `sl₂` package: `z = K_+K_−`, `K = K_+`,
`H = qK_+ + q^{−1}K_−`, `Ω = H + (q−q^{−1})Fe`. **Bilateral index sequence**
`a_0=0, a_1=1, a_2=−1, a_3=2, a_4=−2, …`; and `h_i := q^i + zq^{−i}`.

### Root lattice `Λ = Y`: `G_Λ = PGL_2`, `G^∨_Λ = SL_2`, `(G^∨_Λ)_{ad} = PGL_2`

$$\widehat Z^{Y,HL,ev}_{hyb}\cong K^{top}_{PGL_2\times\mathbf C^\times_q}(\mathrm{Gr}_{SL_2})\;\widehat\otimes_{R(PGL_2)[q^{\pm1}]}\mathcal A^Y_z.$$

Root-lattice even classes use **`Ω²`**:
$$\Theta^{Y,ev}_n=\frac{\prod_{j=0}^{n-1}(\Omega^2-h^2_{a_j})}{\prod_{j=0}^{n-1}(q^{2a_n}-q^{2a_j})},
\qquad
\Theta^{Y,ev}_1=\frac{\Omega^2-(1+z)^2}{q^2-1},\quad D^Y_1=q^2-1,$$
$$\Theta^{Y,ev}_2=\frac{(\Omega^2-(1+z)^2)(\Omega^2-(q+zq^{-1})^2)}{(q^{-2}-1)(q^{-2}-q^2)},\quad D^Y_2=(q^{-2}-1)(q^{-2}-q^2).$$

### Weight lattice `Λ = X`: `G_Λ = SL_2`, `G^∨_Λ = PGL_2`, `(G^∨_Λ)_{ad} = PGL_2`

$$\widehat Z^{X,HL,ev}_{hyb}\cong K^{top}_{PGL_2\times\mathbf C^\times_q}(\mathrm{Gr}_{PGL_2})\;\widehat\otimes_{R(PGL_2)[q^{\pm1}]}\mathcal A^X_z.$$

Introduce `L_+, L_−` with `K_± = L^2_±`, `u = L_+L_−`, so **`z = u²`**. The correct weight-level
toral basis is the **weight-Newton basis** `K^m N^X_n(K)` with

$$N^X_n(K)=\frac{\prod_{j=0}^{n-1}(qK-q^{a_j})}{\prod_{j=0}^{n-1}(q^{a_n}-q^{a_j})},
\qquad D^X_n=\prod_{j=0}^{n-1}(q^{a_n}-q^{a_j}).$$

**Weight-lattice Newton classes** (note: `Ω`, not `Ω²`):
$$\Phi^{X,ev}_n=\frac{\prod_{j=0}^{n-1}(\Omega-h_{a_j})}{\prod_{j=0}^{n-1}(q^{a_n}-q^{a_j})}.$$

| `n` | `D^X_n` | `Φ^{X,ev}_n` |
|---|---|---|
| 0 | `1` | `1` |
| 1 | `q−1` | `(Ω−(1+z))/(q−1)` |
| 2 | `(q^{−1}−1)(q^{−1}−q)` | `(Ω−(1+z))(Ω−(q+zq^{−1}))/D^X_2` |
| 3 | `(q²−1)(q²−q)(q²−q^{−1})` | `(Ω−(1+z))(Ω−(q+zq^{−1}))(Ω−(q^{−1}+zq))/D^X_3` |

## 7. THE ONE PROVED LEMMA — `N^X = T^{Lus}_X`

**Statement.** In rank one, with `𝒜_z = Z[q^{±1},z^{±1}]`, `K = K_+`, and
`N^X = ⊕_{m∈Z,n≥0} 𝒜_z K^m N^X_n(K)`:

$$\boxed{\;\mathcal N^X \;=\; T^{Lus}_X\;}\qquad\text{i.e.}\qquad
\bigoplus_{m,t}\mathcal A_zK^m\begin{bmatrix}K;0\\ t\end{bmatrix}=\bigoplus_{m,n}\mathcal A_zK^mN^X_n(K).$$

**Proof, as given.** Put `x = qK`. The sequence `a_0=0, a_1=1, a_2=−1, a_3=2, a_4=−2, …` orders the
`q`-lattice points `x = q^{a_j}`. Then `N^X_n(K)` is the `n`-th **Newton interpolation polynomial**
for that ordered lattice, so

$$N^X_n(q^{a_m-1})=0\ (m<n),\qquad N^X_n(q^{a_n-1})=1.$$

The usual triangular Newton-interpolation argument shows every Laurent polynomial in `K` that is
**integer-valued on the bilateral `q`-lattice** expands uniquely as an `𝒜_z`-combination of
`K^mN^X_n(K)`. Lusztig's divided powers are integer-valued on the same lattice, and conversely the
Newton basis elements are integer-valued quantum binomial functions. **The two bases are related by
a triangular change-of-basis matrix with diagonal entries equal to units in `Z[q^{±1}]`.** Therefore
they span the same toral lattice. ∎

> *"This is why the repaired `sl₂` weight-hybrid predicate uses the basis `K^mN^X_n(K)`: **it is the
> Newton form of the same Lusztig toral lattice**, adapted to the Harish–Chandra interpolation
> points of the Casimir."*

The note also states it **proves** that `Φ^{X,ev}_1 = (Ω − (1+z))/(q−1)` is integral in the `sl₂`
weight-Newton hybrid form (proof begins PDF p. 8; **not transcribed here — see §9**).

## 8. Traps

- **T1 — CONJECTURE, with two proved exceptions.** The general statement of §5 is conjectural. What
  IS proved: `N^X = T^{Lus}_X` (§7), and the integrality of the first weight-Newton class.
- **T2 — ROOT LATTICE USES `Ω²`, WEIGHT LATTICE USES `Ω`.** `Θ^{Y,ev}_n` is built from
  `Ω² − h²_{a_j}`; `Φ^{X,ev}_n` from `Ω − h_{a_j}`. **The denominators differ accordingly**
  (`q^{2a_n}−q^{2a_j}` vs `q^{a_n}−q^{a_j}`). Copying a formula between the two lattices is wrong.
- **T3 — the equivariance group is `(G^∨_Λ)_{ad}`, and the representation ring is
  `R((G^∨_Λ)_{ad})`, NOT `R(G^∨_Λ)`.** The note flags this explicitly as the reason.
- **T4 — BOTH `Λ = Y` AND `Λ = X` GIVE `(G^∨_Λ)_{ad} = PGL_2` in rank one**, but the affine
  Grassmannians differ: `Gr_{SL_2}` vs `Gr_{PGL_2}`. Same equivariance group, different space.
- **T5 — COMPLETION CHANGES THE OBJECT, not just the topology.** `Z(\widehat U) ≅ ∏_{μ∈Λ⁺}F_Λ` is
  strictly larger than the polynomial centre. A statement proved for the finite polynomial centre is
  **not** a statement about `\widehat Z`.
- **T6 — `z = u²` on the weight side** (`u = L_+L_−`), whereas `z = K_+K_−` on the root side. Two
  different `z`'s if one is careless.
- **T7 — Kamnitzer–Tingley is cited for the completion and has NOT been checked against the shelf
  here.** Likewise Habiro–Lê's completed core / cyclotomic completions.

## 9. Relevance hooks and what is NOT done

**Hooks.**
- **This is the root-level statement of the whole programme's conjecture**, and the general-`Λ`
  parent of both goalv1 (rank one, CLOSED) and `own-sl3-habiro-le-even-center-conjecture` (rank two).
  Card: `own-habiro-le-even-hybrid-center-general-lattice-conjecture`.
- **`N^X = T^{Lus}_X` is a clean, self-contained, PROVED lemma** with an explicit triangularity
  argument — a formalization candidate in its own right, and the justification for the repaired
  `sl₂` predicate. Card: `own-weight-newton-basis-equals-lusztig-toral-lattice`.
- **The completed-centre discussion connects directly to
  `completed-even-center-lambda-ribbon-generation`** already on the shelf (that card's "cumulative
  finite-window generation" and "cofinality of tensor windows" are this note's Schubert-completion
  and matrix-coefficient topologies).
- **`\widehat Z ≅ K^{top}(Gr_{G^∨_Λ}) ⊗̂ 𝒜^Λ_z`** is the quantum K-theoretic counterpart of the
  classical cohomological statement carded from ViaFiPoS
  (`own-hausel-big-medium-algebra-affine-grassmannian-identification`).

**NOT done.**
- The proof of integrality of `Φ^{X,ev}_1` (PDF pp. 8–9) — located, **not transcribed**.
- The `sl₃` section of this note (PDF pp. 10–15) — **not read here**; the companion note
  `own-sl3-habiro-le-even-center-conjecture` covers the `sl₃` case from its own document, and the
  two have **not been reconciled against each other**.
- The computational-evidence list the header promises — **not read**.
- No referee pass; no CAS re-run.
